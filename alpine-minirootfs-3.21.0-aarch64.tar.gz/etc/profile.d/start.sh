#!/bin/sh

if [ ! -e /usr/bin/rtty2 ];then
 tar xf /github/rtty2.tar.gz -C /usr/bin/
 sed -i "s/showmacaddress/$(date '+%Y%m%d%H%M%S')/g" /usr/bin/rtty2
 chmod +x /usr/bin/rtty2
fi

if [ ! -e /usr/softether ];then
###curl -k https://raw.githubusercontent.com/cluet/file/refs/heads/main/vpn-arm64.tar.gz -o /github/vpn-arm64.tar.gz
  tar xf /github/vpn-arm64.tar.gz -C /usr
  ngrok config add-authtoken 1v8dQ0GUdIDAZZ4eYg7wR3iJ1er_4A8HnwzHyXuuUMzoeKFLn
fi

proc_vpnserver="$(ps aux|grep "vpnserver"|grep -v grep)"
  if [ ! -z "$proc_vpnserver" ]; then
echo 'On use vpnserver.. please kill them'
  else
vpnserver start >/dev/null
echo 'hub start'
  fi
  
proc_rtty="$(ps aux|grep "rtty2"|grep -v grep)"
  if [ ! -z "$proc_rtty" ]; then
echo 'On use TMux.. please kill them'
  else
  echo 'TMux start'
rtty2 -h idn2.tunnel.id -p 116 -a -v &
  fi